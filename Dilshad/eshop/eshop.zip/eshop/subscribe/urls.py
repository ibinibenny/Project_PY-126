from django.urls import path
from subscribe import views
urlpatterns = [
    path('chk', views.subscribe, name='subscribe'),
]
