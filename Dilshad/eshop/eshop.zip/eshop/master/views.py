from django.core.files.base import File
from django.shortcuts import render, redirect
from django.views.generic import (
    CreateView,
    ListView,
    DetailView,
    UpdateView,
    DeleteView,
    View,
)
from master.models import ContactusModel, CategoryModel, BookCategoryModel, BooksModel
from master.forms import ContactusForm, CategoryForm, BookCategoryForm, BooksForm


# Create your views here.


class CreateFeedbackView(CreateView):
    template_name = 'create_feedback.html'
    model = ContactusModel
    form_class = ContactusForm
    success_url = '/gen/home'


class FeedbackListView(ListView):
    template_name = 'Feedback_list.html'
    model = ContactusModel
    context_object_name = 'feed'


class FeedbackDetailView(DetailView):
    template_name = 'feedback_details.html'
    model = ContactusModel


class UpdateFeedbackView(UpdateView):
    template_name = 'feedback_update.html'
    fields = ['name', 'email', 'subject', 'message', 'place']
    model = ContactusModel
    success_url = '/mas/feedback_list/'


class DeleteFeedbackView(DeleteView):
    template_name = 'feedback_delete.html'
    model = ContactusModel
    success_url = '/mas/feedback_list/'

    # Product details


class CreateCatagoryView(CreateView):
    template_name = 'create_catagory.html'
    model = CategoryModel
    form_class = CategoryForm
    success_url = '/gen/home'


class CatagoryListView(ListView):
    template_name = 'category_list.html'
    model = CategoryModel
    context_object_name = 'catagory'


class CatagoryDetailView(DetailView):
    template_name = 'catagory_details.html'
    model = CategoryModel


# Books


class CreateBookCategoryView(CreateView):
    template_name = 'booknew.html'
    model = BookCategoryModel
    form_class = BookCategoryForm
    success_url = '/gen/home'


# class BookView(CreateView):
#     template_name = 'create_book.html'
#     model = BooksModel
#     form_class = BooksForm
#     success_url = '/gen/home'


class NewBookCategoryView(View):
    template_name = 'book_new_1.html'
    form_class = BookCategoryForm

    def get(self, request):
        form = self.form_class()
        context = {'cat_form': form}
        return render(request, self.template_name, context)

    def post(self, request):
        form = self.form_class(request.POST)
        if form.is_valid():
            book = BookCategoryModel.objects.create(
                title=request.POST.get('title'),
                cat_code=request.POST.get('cat_code'),
                description=request.POST.get('description'),
            )
            return redirect('/gen/home/')
        else:
            form = self.form_class()
            return render(request, self.template_name, {'form': form})


class ListNewBookCatView(View):
    template_name = 'listnewbook.html'

    def get(self, request):
        list_var = BookCategoryModel.objects.all()
        context = {'catgry': list_var}

        return render(request, self.template_name, context)


class BookCategoryDetailView(View):
    template_name = 'book_cat_detail_view.html'

    def get(self, request, pk):
        obj = BookCategoryModel.objects.get(id=pk)
        context = {'catgry': obj}
        return render(request, self.template_name, context)


class BookcategoryDeleteView(View):
    template_name = 'listnewbook.html'

    def get(self, request, pk):
        book_form = BookCategoryModel.objects.get(id=pk).delete()
        list_var = BookCategoryModel.objects.all()
        context = {
            'catgry': list_var
        }
        return render(request, self.template_name, context)   

class UpdateBookcategoryView(UpdateView):
    template_name = 'book_cat_update.html'
    fields=['title','cat_code','description',]
    model = BookCategoryModel
    success_url = '/gen/home/'     



class BookView(View):
    template_name = 'create_book.html'
    form_class = BooksForm

    def get(self,request):
        form = self.form_class()
        context = {
        'book_form':form
        }
        return render(request,self.template_name,context)

    def post(self,request):
        form = self.form_class(request.POST,request.FILES)
        if form.is_valid():
            add_book = BookCategoryModel.objects.get(id=request.POST.get('title'))
            items = BooksModel.objects.create(
                title = add_book,
                description=request.POST.get('description'),
                author=request.POST.get('author'),
                price=request.POST.get('price'),
                publisher=request.POST.get('publisher'),
                pub_date=request.POST.get('pub_date'),
                coverimg=request.POST.get('coverimg'),
                pubagrmnt=request.POST.get('pubagrmnt')                

                )
            return redirect('/gen/home/')
        else:
            form = self.form_class()
            return render(request,self.template_name,{'form':form})




