from django.contrib import admin

from master.models import ContactusModel, CategoryModel,BookCategoryModel


# Register your models here.


admin.site.register(ContactusModel)
admin.site.register(CategoryModel)
#admin.site.register(BooksModel)
admin.site.register(BookCategoryModel)
