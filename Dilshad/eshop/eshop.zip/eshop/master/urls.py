from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings
from master.views import (
    CreateFeedbackView,
    FeedbackListView,
    FeedbackDetailView,
    CreateCatagoryView,
    CatagoryListView,
    CatagoryDetailView,
    UpdateFeedbackView,
    DeleteFeedbackView,
    CreateBookCategoryView,
    BookView, 
    NewBookCategoryView,
    ListNewBookCatView,
    BookCategoryDetailView,
    BookcategoryDeleteView,
    UpdateBookcategoryView,

)


urlpatterns = [
    path('feedback/', CreateFeedbackView.as_view(), name='Feedback_page'),
    path('feedback_list/', FeedbackListView.as_view(), name='feedback_list_page'),
    path('Feedbackdetails/(?P<pk>[0-9]+)/$',FeedbackDetailView.as_view(), name='FeedbackDetail_page'),
    path('<pk>/update/',UpdateFeedbackView.as_view(),name='update_feed'),
    path('<pk>/delete/', DeleteFeedbackView.as_view(),name='delete_feed'),

    path('addcatagory/', CreateCatagoryView.as_view(), name='catagory_page'),
    path('catagorylist/', CatagoryListView.as_view(), name='catogory_list_page'),
    path('catagorydetails/(?P<pk>[0-9]+)/$', CatagoryDetailView.as_view(), name='catagory_detail_page'),
    
    path('bookcategory/',CreateBookCategoryView.as_view(),name='book_category'),#create view
    path('newbookcat/',NewBookCategoryView.as_view(),name='newbookcategory_page'),#simple view
    
    path('addnewbook/',BookView.as_view(),name='addnewbook_page'),
    path('list_newbookcat/',ListNewBookCatView.as_view(),name='listnewcatbook_page'),
    path('detailbookview/(?P<pk>[0-9]+)/$',BookCategoryDetailView.as_view(),name='bookcategorydetailview_page'),
    path('<pk>/deletebookview/',BookcategoryDeleteView.as_view(),name='bookcat_delete_view_page'),
    path('<pk>/updatebookview/',UpdateBookcategoryView.as_view(),name='bookcat_update_view_page'),



    
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL,
                          document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL,
                          document_root=settings.MEDIA_ROOT)
